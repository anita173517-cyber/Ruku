# StreamX Media3 Pro — v18.1 Next-Generation Ultra Extreme Correct VOD Edition Changelog

## 1. Root Cause Analysis of v18.0 Live TV / Movies / Series Mixing
1. **Heuristic Name/Category/URL Inference (`MediaCatalogEngine.inferSection`):** In v18.0, `Channel.isVodMovie()` and `Channel.isSeriesEpisode()` did not track the origin of a content entry. Instead, they ran regexes (`SERIES_REGEX`, `MOVIE_URL_HINT_REGEX`, `MOVIE_GROUP_HINT_REGEX`) on `name`, `category`, and `streamUrl`. Any M3U or Xtream Live TV channel named `"Bollywood Movies 24x7"`, `"South Movie Mania"`, `"TMKOC 24x7"`, or `"Web Series Live"` was falsely classified as a VOD Movie or Series.
2. **M3U Entries Routed into Movies/Series Grids:** In v18.0, `openVodSectionHub()` scanned `allChannels` for heuristic matches when an M3U profile was active, populating Movies and Series with Live TV channels.
3. **Shared `allChannels` State Overwrite:** In v18.0, loading Xtream VOD (`loadXtreamVodMoviesCatalog`) replaced `allChannels` in memory and persisted into the shared cache, overwriting Live TV channels when switching between Live TV and Movies.

## 2. Architectural Fixes in v18.1
- **Explicit `ContentSourceType` Enum (`Models.kt`):** Every `Channel` now carries an explicit `sourceType` (`M3U_LIVE`, `XTREAM_LIVE`, `XTREAM_VOD_MOVIE`, `XTREAM_SERIES`, `XTREAM_SERIES_EPISODE`). `isVodMovie()`, `isSeriesEpisode()`, `isLiveChannel()`, and `primarySection()` inspect `sourceType` exclusively.
- **M3U / M3U8 = Live TV Only (`M3uParser.kt` & `PlayerActivity.kt`):** Every M3U entry is assigned `ContentSourceType.M3U_LIVE`. For M3U-only profiles, Movies and Series show a clean empty state and never pull from Live TV.
- **Independent Xtream Catalogs (`XtreamRepository.kt`, `ChannelCacheStore.kt`, `PlayerActivity.kt`):**
  - Live TV: `get_live_categories` + `get_live_streams` -> `allChannels` (cache key `live_<scope>`)
  - Movies: `get_vod_categories` + `get_vod_streams` + `get_vod_info` -> `vodMoviesCatalog` (cache key `vod_<scope>`)
  - Series: `get_series_categories` + `get_series` + `get_series_info` -> `seriesCatalogGroups` (cache key `series_<scope>`)
- **Reference-Matched Movies & Series UI (`activity_player.xml`, `PlayerActivity.kt`):**
  - Left VOD Category Sidebar (`vodCategorySidebarRecycler`) with `FAVORITES`, `RECENTLY ADDED`, `CONTINUE WATCHING`, and provider category counts.
  - Top bar with live clock/date (`tvVodLiveClockDate`), `OLD/NEW • A-Z` sort button (`btnVodSortOrder`), `★ Watchlist`, `Continue Watching`, and `Search`.
  - 5-column responsive poster grid (`computeResponsivePosterSpanCount()`).
  - Reference-matched Movie Details (`TRAILER` + `PLAY MOVIE`) and Series Details (`SEASON 1..N` pills + episode rows).
  - Smart Auto Next Episode countdown, per-account Watchlist, per-account Continue Watching (VOD/Series only), Universal Smart Search with source badges, and Smart Low-Memory Mode.
