package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RAM PLAYER v24.1 — Comprehensive HTTP Error Recovery Matrix (379, 400, 401, 403, 404, 429, 5xx, Manifest)
 * & Refresh-Safe Persistent Category Deletion Unit Tests.
 */
class RamPlayerV241HttpAndCategoryTest {

    @Test
    fun classifiesAllMajorAndCustomIptvHttpStatusCodes() {
        assertEquals(
            PlaybackFailureCategory.HTTP_REDIRECT_OR_CUSTOM_3XX,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 379", 379)
        )
        assertEquals(
            PlaybackFailureCategory.HTTP_REDIRECT_OR_CUSTOM_3XX,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 302", 302)
        )
        assertEquals(
            PlaybackFailureCategory.HTTP_BAD_REQUEST,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 400", 400)
        )
        assertEquals(
            PlaybackFailureCategory.HTTP_BAD_REQUEST,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 406", 406)
        )
        assertEquals(
            PlaybackFailureCategory.PROVIDER_AUTH_ERROR,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 401", 401)
        )
        assertEquals(
            PlaybackFailureCategory.PROVIDER_AUTH_ERROR,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 403", 403)
        )
        assertEquals(
            PlaybackFailureCategory.HTTP_NOT_FOUND,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 404", 404)
        )
        assertEquals(
            PlaybackFailureCategory.HTTP_REQUEST_TIMEOUT,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 408", 408)
        )
        assertEquals(
            PlaybackFailureCategory.HTTP_RATE_LIMITED,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 429", 429)
        )
        assertEquals(
            PlaybackFailureCategory.HTTP_GEO_OR_PAYMENT_BLOCKED,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 451", 451)
        )
        assertEquals(
            PlaybackFailureCategory.HTTP_SERVER_ERROR,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 503", 503)
        )
        assertEquals(
            PlaybackFailureCategory.HTTP_CLOUDFLARE_EDGE_ERROR,
            PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 522", 522)
        )
        assertEquals(
            PlaybackFailureCategory.HLS_MANIFEST_ERROR,
            PlaybackRecoveryEngine.classifyFailure(3002, "ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED", "None of the available extractors")
        )
    }

    @Test
    fun extractsHttpStatusCodeFromNestedCauseMessages() {
        assertEquals(379, PlaybackRecoveryEngine.extractHttpStatusCode(0, "Source error", listOf("Response code: 379")))
        assertEquals(400, PlaybackRecoveryEngine.extractHttpStatusCode(0, "HTTP 400 Bad Request"))
        assertEquals(429, PlaybackRecoveryEngine.extractHttpStatusCode(0, null, listOf("status: 429 Too Many Requests")))
        assertEquals(403, PlaybackRecoveryEngine.extractHttpStatusCode(403, "Source error"))
    }

    @Test
    fun recoveryMatrixEnablesSmartMirrorAndFallbacksAcrossAllHttpErrors() {
        val plan379 = StreamHttpErrorRecoveryMatrix.buildPlan(PlaybackFailureCategory.HTTP_REDIRECT_OR_CUSTOM_3XX, 379)
        assertTrue(plan379.shouldRotateUserAgent)
        assertTrue(plan379.shouldTryUrlVariants)
        assertTrue(plan379.allowSmartMirror)

        val plan401 = StreamHttpErrorRecoveryMatrix.buildPlan(PlaybackFailureCategory.PROVIDER_AUTH_ERROR, 401)
        assertTrue(plan401.shouldRotateUserAgent)
        assertTrue(plan401.includeOriginReferer)
        assertTrue(plan401.allowSmartMirror)

        val plan404 = StreamHttpErrorRecoveryMatrix.buildPlan(PlaybackFailureCategory.HTTP_NOT_FOUND, 404)
        assertTrue(plan404.shouldTryUrlVariants)
        assertTrue(plan404.allowSmartMirror)

        val plan429 = StreamHttpErrorRecoveryMatrix.buildPlan(PlaybackFailureCategory.HTTP_RATE_LIMITED, 429)
        assertTrue(plan429.shouldEvictConnections)
        assertTrue(plan429.shouldRotateUserAgent)
        assertTrue(plan429.allowSmartMirror)

        val planManifest = StreamHttpErrorRecoveryMatrix.buildPlan(PlaybackFailureCategory.HLS_MANIFEST_ERROR, 0)
        assertTrue(planManifest.shouldTryMimeEscalation)
        assertTrue(planManifest.shouldTryUrlVariants)
        assertTrue(planManifest.allowSmartMirror)
    }

    @Test
    fun urlFallbackCandidatesSwapExtensionsAndSchemesCleanly() {
        val hlsAlts = StreamHttpErrorRecoveryMatrix.buildUrlFallbackCandidates("https://iptv.example.com/live/u/p/101.m3u8?tok=1")
        assertTrue(hlsAlts.contains("https://iptv.example.com/live/u/p/101.ts?tok=1"))
        assertTrue(hlsAlts.contains("http://iptv.example.com/live/u/p/101.m3u8?tok=1"))
        assertFalse(hlsAlts.contains("https://iptv.example.com/live/u/p/101.m3u8?tok=1"))

        val tsAlts = StreamHttpErrorRecoveryMatrix.buildUrlFallbackCandidates("http://iptv.example.com/live/u/p/202.ts")
        assertTrue(tsAlts.contains("http://iptv.example.com/live/u/p/202.m3u8"))
        assertTrue(tsAlts.contains("https://iptv.example.com/live/u/p/202.ts"))

        val extlessAlts = StreamHttpErrorRecoveryMatrix.buildUrlFallbackCandidates("http://iptv.example.com/live/u/p/303")
        assertTrue(extlessAlts.contains("http://iptv.example.com/live/u/p/303.m3u8"))
        assertTrue(extlessAlts.contains("http://iptv.example.com/live/u/p/303.ts"))
    }

    @Test
    fun deletedCategoriesRemainFilteredAfterPlaylistRefreshAcrossLiveMoviesAndSeries() {
        val refreshedCatalog = listOf(
            Channel(id = "1", number = 1, name = "Sony Max HD", category = "Hindi Movies", streamUrl = "http://s/1.m3u8", sourceType = ContentSourceType.M3U_LIVE),
            Channel(id = "2", number = 2, name = "UK News", category = "UK Sports", streamUrl = "http://s/2.m3u8", sourceType = ContentSourceType.M3U_LIVE),
            Channel(id = "3", number = 3, name = "Action Movie", category = "Adult 18+", streamUrl = "http://s/3.mp4", sourceType = ContentSourceType.XTREAM_VOD_MOVIE),
            Channel(id = "4", number = 4, name = "Drama Show", category = "Hindi Series", streamUrl = "http://s/4.m3u8", sourceType = ContentSourceType.XTREAM_SERIES)
        )
        val deletedCats = setOf("uk sports", "Adult 18+")
        val activeAfterRefresh = ChannelDeletionFilter.filterActiveChannels(
            rawChannels = refreshedCatalog,
            deletedCategories = deletedCats,
            deletedChannelKeys = emptySet()
        )
        assertEquals(2, activeAfterRefresh.size)
        assertTrue(activeAfterRefresh.any { it.name == "Sony Max HD" })
        assertTrue(activeAfterRefresh.any { it.name == "Drama Show" })
        assertFalse(activeAfterRefresh.any { it.category.equals("UK Sports", ignoreCase = true) })
        assertFalse(activeAfterRefresh.any { it.category.equals("Adult 18+", ignoreCase = true) })
    }
}
