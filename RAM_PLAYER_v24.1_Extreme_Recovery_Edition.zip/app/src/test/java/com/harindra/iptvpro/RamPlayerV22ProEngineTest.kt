package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetAddress
import java.net.UnknownHostException

/**
 * RAM PLAYER v22.0 — Black-Screen Elimination & Android TV Pro Engine Automated Unit Tests.
 */
class RamPlayerV22ProEngineTest {

    @Test
    fun blackScreenDiagnosticsDistinguishesAllFailureCategories() {
        val ok = BlackScreenDiagnosticsEngine.diagnose(1, 1, 1, hasRenderedFrame = true)
        assertEquals(BlackScreenReason.VIDEO_OK, ok.reason)
        assertFalse(ok.reason.isRecoverable)

        val audioOnly = BlackScreenDiagnosticsEngine.diagnose(0, 0, 1, hasRenderedFrame = false)
        assertEquals(BlackScreenReason.AUDIO_ONLY_STREAM, audioOnly.reason)
        assertFalse(audioOnly.reason.isRecoverable)

        val unsupportedCodec = BlackScreenDiagnosticsEngine.diagnose(1, 0, 1, hasRenderedFrame = false, videoCodec = "video/hevc")
        assertEquals(BlackScreenReason.UNSUPPORTED_VIDEO_CODEC, unsupportedCodec.reason)
        assertTrue(unsupportedCodec.reason.isRecoverable)

        val lowRam4k = BlackScreenDiagnosticsEngine.diagnose(1, 1, 1, hasRenderedFrame = false, isLowRamDevice = true, videoHeight = 2160)
        assertEquals(BlackScreenReason.UNSUPPORTED_RESOLUTION, lowRam4k.reason)

        val drm = BlackScreenDiagnosticsEngine.diagnose(1, 1, 1, hasRenderedFrame = false, isDrmError = true)
        assertEquals(BlackScreenReason.DRM_LICENSE_ERROR, drm.reason)
        assertFalse(drm.reason.isRecoverable)

        val auth = BlackScreenDiagnosticsEngine.diagnose(1, 1, 1, hasRenderedFrame = false, isAuthError = true)
        assertEquals(BlackScreenReason.EXPIRED_TOKEN, auth.reason)

        val stall = BlackScreenDiagnosticsEngine.diagnose(1, 1, 1, hasRenderedFrame = false)
        assertEquals(BlackScreenReason.RENDERER_SURFACE_STALL, stall.reason)
        assertTrue(stall.reason.isRecoverable)
    }

    @Test
    fun smartMirrorRecoveryNormalizesNamesAndPreventsLoops() {
        assertEquals("star sports 1", SmartMirrorRecoveryEngine.normalizeChannelMirrorKey("IN: Star Sports 1 FHD"))
        assertEquals("star sports 1", SmartMirrorRecoveryEngine.normalizeChannelMirrorKey("Star Sports 1 HD Backup"))
        assertEquals("sony sab", SmartMirrorRecoveryEngine.normalizeChannelMirrorKey("IND Sony SAB 1080p Server 2"))

        val primary = Channel("ch_1", 1, "IN: Star Sports 1 4K", "Sports", "https://cdn.example/ss1_4k.m3u8")
        val mirrorHd = Channel("ch_2", 2, "Star Sports 1 HD Backup", "Sports", "https://cdn.example/ss1_hd.m3u8")
        val unrelated = Channel("ch_3", 3, "Aaj Tak HD", "News", "https://cdn.example/aaj.m3u8")

        val found = SmartMirrorRecoveryEngine.findBestMirrorCandidate(
            failedChannel = primary,
            playlistChannels = listOf(primary, mirrorHd, unrelated),
            alreadyTriedIds = setOf(primary.id)
        )
        assertNotNull(found)
        assertEquals("ch_2", found?.id)

        // Loop prevention: once mirror is tried, must return null
        val none = SmartMirrorRecoveryEngine.findBestMirrorCandidate(
            failedChannel = primary,
            playlistChannels = listOf(primary, mirrorHd, unrelated),
            alreadyTriedIds = setOf(primary.id, mirrorHd.id)
        )
        assertNull(none)
    }

    @Test
    fun channelScannerDistinguishesDeadTempAndAuthResponses() {
        assertEquals(DeadChannelClassification.ALIVE, ChannelScannerEngine.classifyHttpResponse(200, "application/vnd.apple.mpegurl"))
        assertEquals(DeadChannelClassification.SUSPECTED_DEAD, ChannelScannerEngine.classifyHttpResponse(200, "text/html; charset=utf-8"))
        assertEquals(DeadChannelClassification.SUSPECTED_DEAD, ChannelScannerEngine.classifyHttpResponse(404, null))
        assertEquals(DeadChannelClassification.SUSPECTED_DEAD, ChannelScannerEngine.classifyHttpResponse(410, null))
        assertEquals(DeadChannelClassification.AUTH_OR_RESTRICTED, ChannelScannerEngine.classifyHttpResponse(403, null))
        assertEquals(DeadChannelClassification.TEMP_ERROR, ChannelScannerEngine.classifyHttpResponse(503, null))
        assertEquals(DeadChannelClassification.TEMP_ERROR, ChannelScannerEngine.classifyHttpResponse(429, null))
        assertEquals(DeadChannelClassification.SUSPECTED_DEAD, ChannelScannerEngine.classifyException(UnknownHostException("bad.host")))
    }

    @Test
    fun numericEntryControllerSupportsDigitsNumpadAndConflictFreeZeroRecall() {
        val ctrl = NumericChannelEntryController(autoConfirmMs = 1_200L)
        assertEquals(0, ctrl.keyCodeToDigit(7))
        assertEquals(9, ctrl.keyCodeToDigit(16))
        assertEquals(0, ctrl.keyCodeToDigit(144))
        assertEquals(5, ctrl.keyCodeToDigit(149))
        assertNull(ctrl.keyCodeToDigit(23))

        // When buffer is empty and zeroRecallEnabled=true, '0' triggers Last Channel
        assertTrue(ctrl.shouldTreatZeroAsLastChannel(7, zeroRecallEnabled = true))
        assertFalse(ctrl.shouldTreatZeroAsLastChannel(7, zeroRecallEnabled = false))

        // Once '1' is typed, typing '0' then '5' builds channel 105 (NEVER triggers Last Channel!)
        ctrl.appendDigit(1)
        assertFalse(ctrl.shouldTreatZeroAsLastChannel(7, zeroRecallEnabled = true))
        ctrl.appendDigit(0)
        ctrl.appendDigit(5)
        assertEquals("105", ctrl.currentText())
        assertEquals(105, ctrl.consumeTargetNumber())
        assertFalse(ctrl.hasPendingInput())
    }

    @Test
    fun dohModesTunnelingModesAndIpv4DnsOrderingWorkCorrectly() {
        assertEquals(TunnelingMode.AUTO, TunnelingMode.fromId(null))
        assertEquals(TunnelingMode.FORCE_ON, TunnelingMode.AUTO.nextMode())
        assertEquals(TunnelingMode.OFF, TunnelingMode.FORCE_ON.nextMode())

        assertEquals(DohProvider.OFF, DohProvider.fromId(null))
        assertEquals(DohProvider.CLOUDFLARE, DohProvider.OFF.nextProvider())
        assertEquals(DohProvider.GOOGLE, DohProvider.CLOUDFLARE.nextProvider())

        val v6 = InetAddress.getByName("2606:4700:4700::1111")
        val v4 = InetAddress.getByName("1.1.1.1")
        val ordered = NetworkClient.orderAddressesByIpPreference(listOf(v6, v4), preferIpv4 = true)
        assertEquals(v4, ordered.first())
        assertEquals("star sports 1 hd", ChannelSqliteStore.normalizeForIndex("  Star-Sports_1 HD! "))
    }
}
