package com.harindra.iptvpro

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * RAM PLAYER v22.0 — Lightweight Zero-Dependency SQLite Channel Database & Dead Channel Store.
 *
 * Designed for 512MB RAM Android TVs handling 30,000–100,000+ channels:
 * - Batched SQLite transactions during playlist import (`replaceChannelsForScope`).
 * - Indexed columns on `(account_scope, category)`, `(account_scope, name_norm)`, `(account_scope, number)`.
 * - Runtime FTS5 availability check with reliable indexed `LIKE` fallback when FTS5 is absent.
 * - Paginated queries (`queryChannelsPaged`) so RecyclerView never needs to load 100k rows at once.
 * - Separate `dead_channels` table for the Idle-Time Dead Channel Sweeper (non-destructive, restorable).
 * - Coexists safely alongside `ChannelCacheStore` (SXB2) without deleting existing user data.
 */
class ChannelSqliteStore(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DB_NAME,
    null,
    DB_VERSION
) {
    companion object {
        private const val DB_NAME = "ram_player_channels_v22.db"
        private const val DB_VERSION = 1
        private const val TABLE_CHANNELS = "channels"
        private const val TABLE_DEAD = "dead_channels"
        private const val TABLE_FTS = "channels_fts"
        private const val MAX_ROWS_PER_SCOPE = 100_000

        fun normalizeForIndex(raw: String): String {
            return SearchIntelligenceEngine.normalizeSearchText(raw)
        }
    }

    @Volatile
    private var fts5Available: Boolean = false

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS $TABLE_CHANNELS (
                account_scope TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                number INTEGER NOT NULL,
                name TEXT NOT NULL,
                name_norm TEXT NOT NULL,
                category TEXT NOT NULL,
                category_norm TEXT NOT NULL,
                stream_url TEXT NOT NULL,
                logo_url TEXT NOT NULL DEFAULT '',
                epg_id TEXT NOT NULL DEFAULT '',
                backup_url TEXT NOT NULL DEFAULT '',
                source_type TEXT NOT NULL DEFAULT 'M3U_LIVE',
                category_id TEXT NOT NULL DEFAULT '',
                PRIMARY KEY (account_scope, channel_id)
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ch_scope_cat ON $TABLE_CHANNELS(account_scope, category_norm, number)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ch_scope_name ON $TABLE_CHANNELS(account_scope, name_norm)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ch_scope_num ON $TABLE_CHANNELS(account_scope, number)")

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS $TABLE_DEAD (
                account_scope TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                channel_name TEXT NOT NULL,
                category TEXT NOT NULL,
                stream_url TEXT NOT NULL,
                reason TEXT NOT NULL,
                http_code INTEGER NOT NULL DEFAULT 0,
                marked_at_ms INTEGER NOT NULL,
                PRIMARY KEY (account_scope, channel_id)
            )
            """.trimIndent()
        )

        // Probe FTS5 safely at creation time; fall back to indexed LIKE if unavailable on older TV ROMs
        fts5Available = runCatching {
            db.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS $TABLE_FTS USING fts5(account_scope UNINDEXED, channel_id UNINDEXED, name_norm, category_norm)")
            true
        }.getOrDefault(false)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Safe non-destructive migration path
        onCreate(db)
    }

    override fun onOpen(db: SQLiteDatabase) {
        super.onOpen(db)
        fts5Available = runCatching {
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(TABLE_FTS)).use { c ->
                c.moveToFirst()
            }
        }.getOrDefault(false)
    }

    fun isFts5Supported(): Boolean = fts5Available

    suspend fun replaceChannelsForScope(accountScope: String, channels: List<Channel>): Int = withContext(Dispatchers.IO) {
        val scope = accountScope.ifBlank { "default" }
        val limit = channels.size.coerceAtMost(MAX_ROWS_PER_SCOPE)
        val db = writableDatabase
        db.beginTransactionNonExclusive()
        try {
            db.delete(TABLE_CHANNELS, "account_scope = ?", arrayOf(scope))
            if (fts5Available) {
                runCatching { db.delete(TABLE_FTS, "account_scope = ?", arrayOf(scope)) }
            }
            val insertSql = """
                INSERT OR REPLACE INTO $TABLE_CHANNELS
                (account_scope, channel_id, number, name, name_norm, category, category_norm, stream_url, logo_url, epg_id, backup_url, source_type, category_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """.trimIndent()
            val stmt = db.compileStatement(insertSql)
            val ftsStmt = if (fts5Available) {
                runCatching {
                    db.compileStatement("INSERT INTO $TABLE_FTS (account_scope, channel_id, name_norm, category_norm) VALUES (?, ?, ?, ?)")
                }.getOrNull()
            } else null

            for (i in 0 until limit) {
                val ch = channels[i]
                val nameNorm = normalizeForIndex(ch.name)
                val catNorm = ch.category.trim().lowercase(Locale.ROOT)
                stmt.clearBindings()
                stmt.bindString(1, scope)
                stmt.bindString(2, ch.id)
                stmt.bindLong(3, ch.number.toLong())
                stmt.bindString(4, ch.name)
                stmt.bindString(5, nameNorm)
                stmt.bindString(6, ch.category)
                stmt.bindString(7, catNorm)
                stmt.bindString(8, ch.streamUrl)
                stmt.bindString(9, ch.logoUrl)
                stmt.bindString(10, ch.epgId)
                stmt.bindString(11, ch.backupUrl)
                stmt.bindString(12, ch.sourceType.code)
                stmt.bindString(13, ch.categoryId)
                stmt.executeInsert()

                if (ftsStmt != null) {
                    ftsStmt.clearBindings()
                    ftsStmt.bindString(1, scope)
                    ftsStmt.bindString(2, ch.id)
                    ftsStmt.bindString(3, nameNorm)
                    ftsStmt.bindString(4, catNorm)
                    ftsStmt.executeInsert()
                }
            }
            stmt.close()
            ftsStmt?.close()
            db.setTransactionSuccessful()
            limit
        } catch (e: Exception) {
            Log.w("StreamX", "SQLite channel import warning: ${e.message}")
            0
        } finally {
            db.endTransaction()
        }
    }

    suspend fun queryChannelsPaged(
        accountScope: String,
        query: String = "",
        category: String = "",
        limit: Int = 200,
        offset: Int = 0
    ): List<Channel> = withContext(Dispatchers.IO) {
        val scope = accountScope.ifBlank { "default" }
        val db = readableDatabase
        val out = ArrayList<Channel>(limit.coerceIn(16, 500))
        val normQuery = normalizeForIndex(query)
        val normCat = category.trim().lowercase(Locale.ROOT)
        val hasCat = normCat.isNotEmpty() && normCat != "all categories"

        val whereParts = ArrayList<String>(3)
        val args = ArrayList<String>(4)
        whereParts.add("account_scope = ?")
        args.add(scope)
        if (hasCat) {
            whereParts.add("category_norm = ?")
            args.add(normCat)
        }
        if (normQuery.isNotEmpty()) {
            whereParts.add("(name_norm LIKE ? OR category_norm LIKE ? OR CAST(number AS TEXT) = ?)")
            val pattern = "%$normQuery%"
            args.add(pattern)
            args.add(pattern)
            args.add(query.trim())
        }

        val sql = """
            SELECT channel_id, number, name, category, stream_url, logo_url, epg_id, backup_url, source_type, category_id
            FROM $TABLE_CHANNELS
            WHERE ${whereParts.joinToString(" AND ")}
            ORDER BY number ASC
            LIMIT ${limit.coerceIn(1, 2000)} OFFSET ${offset.coerceAtLeast(0)}
        """.trimIndent()

        runCatching {
            db.rawQuery(sql, args.toTypedArray()).use { c ->
                while (c.moveToNext()) {
                    out.add(
                        Channel(
                            id = c.getString(0),
                            number = c.getInt(1),
                            name = c.getString(2),
                            category = c.getString(3),
                            streamUrl = c.getString(4),
                            logoUrl = c.getString(5),
                            epgId = c.getString(6),
                            backupUrl = c.getString(7),
                            sourceType = ContentSourceType.fromCode(c.getString(8)),
                            categoryId = c.getString(9)
                        )
                    )
                }
            }
        }
        out
    }

    suspend fun countChannels(accountScope: String): Int = withContext(Dispatchers.IO) {
        val scope = accountScope.ifBlank { "default" }
        runCatching {
            readableDatabase.rawQuery(
                "SELECT COUNT(*) FROM $TABLE_CHANNELS WHERE account_scope = ?",
                arrayOf(scope)
            ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
        }.getOrDefault(0)
    }

    // =========================================================================
    // DEAD CHANNEL SWEEPER STORAGE (SEPARATE FOLDER, NON-DESTRUCTIVE)
    // =========================================================================

    data class DeadChannelRecord(
        val channelId: String,
        val channelName: String,
        val category: String,
        val streamUrl: String,
        val reason: String,
        val httpCode: Int,
        val markedAtMs: Long
    )

    suspend fun markSuspectedDead(
        accountScope: String,
        channel: Channel,
        reason: String,
        httpCode: Int
    ) = withContext(Dispatchers.IO) {
        val scope = accountScope.ifBlank { "default" }
        val cv = ContentValues().apply {
            put("account_scope", scope)
            put("channel_id", channel.id)
            put("channel_name", channel.name)
            put("category", channel.category)
            put("stream_url", channel.streamUrl)
            put("reason", reason)
            put("http_code", httpCode)
            put("marked_at_ms", System.currentTimeMillis())
        }
        runCatching {
            writableDatabase.insertWithOnConflict(TABLE_DEAD, null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        }
    }

    suspend fun getSuspectedDeadChannels(accountScope: String): List<DeadChannelRecord> = withContext(Dispatchers.IO) {
        val scope = accountScope.ifBlank { "default" }
        val out = ArrayList<DeadChannelRecord>()
        runCatching {
            readableDatabase.rawQuery(
                "SELECT channel_id, channel_name, category, stream_url, reason, http_code, marked_at_ms FROM $TABLE_DEAD WHERE account_scope = ? ORDER BY marked_at_ms DESC",
                arrayOf(scope)
            ).use { c ->
                while (c.moveToNext()) {
                    out.add(
                        DeadChannelRecord(
                            channelId = c.getString(0),
                            channelName = c.getString(1),
                            category = c.getString(2),
                            streamUrl = c.getString(3),
                            reason = c.getString(4),
                            httpCode = c.getInt(5),
                            markedAtMs = c.getLong(6)
                        )
                    )
                }
            }
        }
        out
    }

    suspend fun restoreDeadChannel(accountScope: String, channelId: String) = withContext(Dispatchers.IO) {
        val scope = accountScope.ifBlank { "default" }
        runCatching {
            writableDatabase.delete(TABLE_DEAD, "account_scope = ? AND channel_id = ?", arrayOf(scope, channelId))
        }
    }

    suspend fun clearDeadChannels(accountScope: String) = withContext(Dispatchers.IO) {
        val scope = accountScope.ifBlank { "default" }
        runCatching {
            writableDatabase.delete(TABLE_DEAD, "account_scope = ?", arrayOf(scope))
        }
    }
}
